#!/bin/sh
java -jar retrotranslator-transformer-1.2.2.jar -advanced -srcjar ../lib/struts2-core-2.0.11.2.jar -destjar struts2-core-j4-2.0.11.2.jar
java -jar retrotranslator-transformer-1.2.2.jar -advanced -srcjar ../lib/xwork-2.0.5.jar -destjar xwork-j4-2.0.5.jar 
