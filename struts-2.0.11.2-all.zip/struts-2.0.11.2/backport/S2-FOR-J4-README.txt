STRUTS 2 FOR JAVA 4

Struts 2 is targeted for Java 5, but a "backported" version to Java 4 is being made available, 
using the RetroTranslator tool. 

To use Struts 2 with Java 4 (preferably Java 1.4.2), place the enclosed Struts, XWork, 
RetroTranslator, and backport-util-concurrent JARs on your classpath. For complete details on 
using RetroTranslator JARs, see the RetroTranslator site. 

* http://retrotranslator.sourceforge.net/

NOTE: The Struts 2 and XWork 2 JARs are complete replacements for the corresponding standard 
Java 5 JARs. Do not use both sets of JARs in the same environment! 

If you discover any issues using the Struts 2 for Java 4 JAR, please report them to the Struts 
Dev list or JIRA ticket ww-1391. 

* http://struts.apache.org/mail.html

* https://issues.apache.org/struts/browse/WW-1391

Cheers!
